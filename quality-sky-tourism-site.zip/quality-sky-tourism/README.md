# Quality Sky Tourism by Tudose

Prima versiune gratuită a site-ului, într-un singur fișier `index.html`.

## Publicare gratuită pe GitHub Pages

1. Creează un cont pe https://github.com/signup (dacă nu ai unul).
2. Din GitHub apasă **New repository**.
3. Nume: `quality-sky-tourism`; selectează **Public** și **Create repository**.
4. În repository, apasă **Add file → Upload files** și încarcă fișierul `index.html` (nu folderul și nu ZIP-ul). Apasă **Commit changes**.
5. Intră la **Settings → Pages**.
6. La **Build and deployment**, alege **Deploy from a branch**. Selectează `main` și `/ (root)`, apoi **Save**.
7. După publicare, adresa va fi în mod normal `https://NUME-UTILIZATOR.github.io/quality-sky-tourism/`. Poate dura câteva minute până se activează.

## Personalizare

- Logo-ul din această versiune este un `Q` stilizat în CSS, nu sigla finală.
- Înlocuiește linkul către căutarea Facebook cu linkul exact al paginii oficiale.
- Fotografiile sunt externe, ilustrative și necesită internet. Nu sunt imagini cu proprietatea proiectului și nu sunt garantate ca fiind din locurile menționate.
- Pentru a schimba imaginile, modifică URL-urile `images.unsplash.com` din `index.html`. Verifică licențele și atribuirea înainte de utilizarea comercială.
- Site-ul este static: nu include procesare de rezervări, formular cu backend sau plăți.
- Găzduirea GitHub Pages este gratuită pentru acest tip de proiect public, sub rezerva regulilor serviciului. Domeniul propriu costă separat.
